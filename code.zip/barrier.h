#ifndef BARRIER_H
#define BARRIER_H

void drawBarrier(int x, int y);
void barBarrier();

#endif