#ifndef MAINMENU_H
#define MAINMENU_H


void showMainMenu(); // Menampilkan menu utama
void startGame();
#endif
