#ifndef MAINMENU_H
#define MAINMENU_H

extern void startGame();

void showMainMenu(); // Menampilkan menu utama
void startGame();    // Fungsi untuk memulai permainan
void handleMainMenu();

#endif
