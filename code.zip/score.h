#ifndef SCORE_H
#define SCORE_H

void initScore();
void updateScore(int points);
void drawScore();
int getScore();
void addAlienScore();
void addUFOScore();

#endif