#include <stdio.h>

int main(){
    int array[] = {4, 5, 2, 7};
    int *px;
    px = array + 2;
    printf("%d", *px);
}