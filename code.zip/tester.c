#include "stdio.h"

int main(){
    char a[5] = "BABA";
    char b[5] = "BUBU";
    char c[5];

    printf("%s\n", a);
    printf("%s\n", b);

    c = b;
    b = a;

    printf("%s\n", a);
    printf("%s\n", b);
    printf("%s\n", c);
}