// ufo.h
#ifndef UFO_H
#define UFO_H
#include <graphics.h>

extern int ufoX, ufoY, ufoActive;


void drawUFO(int x, int y);
void drawBullet(int bx, int by);
void moveUFO();

#endif
